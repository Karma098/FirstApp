package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btn: Button =findViewById(R.id.btn_submit)
        val txt:EditText=findViewById(R.id.et_text)
        btn.setOnClickListener(View.OnClickListener {
            print("hii")
            print(txt)
            print("Go Corona Go")
        })
    }
}